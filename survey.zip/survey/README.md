# Survey Custom Site (Custom UI + Google Sheet)

這個版本是「自訂前端表單 + Google Apps Script 寫入 Google 試算表」，可部署在 GitHub Pages。

## 你會得到什麼

- 完全自訂的表單樣式（不是 Google Forms 原生 UI）
- 送出後可寫入 Google 試算表
- 保留活動官網互動區塊（倒數、導覽、FAQ、交通切換）

## 1) 前端設定

1. 打開 `config.js`
2. 填入 `googleScriptEndpoint`（你部署完成的 Apps Script Web App URL）
3. `useNoCors` 建議維持 `true`

## 2) Google 試算表準備

1. 建立一份試算表
2. 第一列建立欄位（標題可自由，但建議如下）：

- Name
- Adults
- Kids
- Vegetarian
- Attending
- Message
- SourceTag
- SubmittedAt
- UserAgent
- Page

## 3) Apps Script 程式

在該試算表點 `Extensions -> Apps Script`，貼上：

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sheet1');
  var payload = {};

  try {
    payload = JSON.parse(e.postData.contents || '{}');
  } catch (err) {
    payload = {};
  }

  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var row = headers.map(function (header) {
    var key = normalizeHeader(header);

    if (isTimestampHeader(key)) {
      return payload.submittedAt || new Date().toISOString();
    }

    var value = pickMappedValue(key, payload);
    return value === undefined ? '' : value;
  });

  sheet.appendRow(row);

  return ContentService
    .createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function isTimestampHeader(headerKey) {
  var timestampKeys = {
    timestamp: true,
    submittedat: true,
    time: true,
    datetime: true,
    '時間戳記': true,
    '時間': true,
    '填答時間': true,
    '提交時間': true
  };

  return !!timestampKeys[headerKey];
}

function normalizeHeader(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[\s\-*?()（）:：/]/g, '');
}

function pickMappedValue(headerKey, payload) {
  var map = {
    name: payload.name,
    '1name': payload.name,
    adults: payload.adults,
    '2adults': payload.adults,
    kids: payload.kids,
    '3kids': payload.kids,
    vegetarian: payload.vegetarian,
    vagitarian: payload.vagitarian,
    '4vagitarian': payload.vagitarian,
    attending: payload.attending,
    realinvitation: payload.realInvitation,
    '5realinvitation': payload.realInvitation,
    message: payload.message,
    anyword: payload.anyWord,
    '6anyword': payload.anyWord,
    sourcetag: payload.sourceTag,
    useragent: payload.userAgent,
    page: payload.page,
    totalguests: payload.totalGuests
  };

  return map[headerKey];
}
```

注意：如果你的工作表分頁不是 `Sheet1`，請改成實際名稱。

如果你是寫入「Google 表單回應」那張工作表，這段程式會依第一列欄位標題自動對齊，不會因欄位順序不同而錯位。

## 4) 部署 Web App

1. 點 `Deploy -> New deployment`
2. Type 選 `Web app`
3. Execute as 選 `Me`
4. Who has access 選 `Anyone`
5. Deploy 後複製 Web App URL（結尾通常是 `/exec`）
6. 貼到 `config.js` 的 `googleScriptEndpoint`

## 5) 上線

1. 推上 GitHub
2. 啟用 GitHub Pages
3. 實測送出後，確認試算表新增資料列

## 常見問題

- 送出失敗：通常是 `googleScriptEndpoint` 空白、URL 貼錯、或 Apps Script 未重新部署。
- 改過 Apps Script 程式後：記得重新 Deploy 新版本，舊 URL 可能仍指向舊版程式。
- 自訂填寫欄位和 Google 表單欄位不一致：使用上面的「標題自動對齊」版本並重新部署。
