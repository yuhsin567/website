(function () {
  const heroEl = document.querySelector(".hero");
  const jumpBtns = Array.from(document.querySelectorAll(".jump-btn"));
  const floatingRsvp = document.getElementById("floatingRsvp");
  const transportTabs = Array.from(document.querySelectorAll(".transport-tab"));
  const progressFill = document.getElementById("progressFill");

  const form = document.getElementById("invitationForm");
  const statusEl = document.getElementById("status");
  const submitBtn = document.getElementById("submitBtn");

  const cfg = window.APP_CONFIG || {};
  const sourceTag = cfg.sourceTag || "github-pages";
  const endpoint = cfg.googleScriptEndpoint || "";
  const useNoCors = cfg.useNoCors !== false;

  const setCountdown = () => {
    if (!heroEl) {
      return;
    }

    const eventTimeRaw = heroEl.getAttribute("data-event-time");
    const end = eventTimeRaw ? new Date(eventTimeRaw).getTime() : NaN;
    if (!Number.isFinite(end)) {
      return;
    }

    const now = Date.now();
    const diff = Math.max(0, end - now);
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const mins = Math.floor((diff / (1000 * 60)) % 60);

    const dayEl = document.getElementById("countDays");
    const hourEl = document.getElementById("countHours");
    const minEl = document.getElementById("countMins");
    if (dayEl) dayEl.textContent = String(days);
    if (hourEl) hourEl.textContent = String(hours).padStart(2, "0");
    if (minEl) minEl.textContent = String(mins).padStart(2, "0");
  };

  const smoothJumpTo = (id) => {
    const target = document.getElementById(id);
    if (!target) {
      return;
    }

    target.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  };

  const updateTransportTab = (panelId) => {
    transportTabs.forEach((tab) => {
      const active = tab.dataset.panel === panelId;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", active ? "true" : "false");
    });

    document.querySelectorAll(".transport-panel").forEach((panel) => {
      const active = panel.id === panelId;
      panel.classList.toggle("active", active);
      panel.hidden = !active;
    });
  };

  const toggleFloatingRsvp = () => {
    if (!floatingRsvp) {
      return;
    }

    const show = window.scrollY > 520;
    floatingRsvp.classList.toggle("show", show);
  };

  const renderStatus = (message, type) => {
    if (!statusEl) {
      return;
    }

    statusEl.textContent = message;
    statusEl.classList.remove("ok", "err");
    if (type) {
      statusEl.classList.add(type);
    }
  };

  const toInt = (value) => {
    const n = Number.parseInt(value, 10);
    return Number.isFinite(n) ? n : 0;
  };

  const validate = (payload) => {
    if (!payload.name.trim()) {
      return "請填寫姓名。";
    }

    if (payload.adults < 0 || payload.kids < 0 || payload.vegetarian < 0) {
      return "人數不可小於 0。";
    }

    if (payload.vegetarian > payload.adults + payload.kids) {
      return "素食者人數不可大於總參加人數。";
    }

    return "";
  };

  const updateProgress = () => {
    if (!form || !progressFill) {
      return;
    }

    let done = 0;
    const total = 4;

    if ((form.elements.name.value || "").trim()) done += 1;
    if ((form.elements.adults.value || "") !== "") done += 1;
    if ((form.elements.kids.value || "") !== "") done += 1;
    if ((form.elements.vegetarian.value || "") !== "") done += 1;

    progressFill.style.width = Math.round((done / total) * 100) + "%";
  };

  jumpBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.target;
      if (target) {
        smoothJumpTo(target);
      }
    });
  });

  if (floatingRsvp) {
    floatingRsvp.addEventListener("click", () => smoothJumpTo("rsvp"));
  }

  transportTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const panelId = tab.dataset.panel;
      if (panelId) {
        updateTransportTab(panelId);
      }
    });
  });

  if (form) {
    ["input", "change"].forEach((eventName) => {
      form.addEventListener(eventName, updateProgress);
    });

    form.addEventListener("submit", async (event) => {
      event.preventDefault();

      const fd = new FormData(form);

      // Honeypot anti-spam field: if it has a value, skip submission silently.
      if ((fd.get("website") || "").toString().trim()) {
        renderStatus("已送出。", "ok");
        form.reset();
        updateProgress();
        return;
      }

      const payload = {
        name: (fd.get("name") || "").toString(),
        adults: toInt(fd.get("adults") || "0"),
        kids: toInt(fd.get("kids") || "0"),
        vegetarian: toInt(fd.get("vegetarian") || "0"),
        attending: "",
        // Compatibility keys for existing Google Form column names.
        realInvitation: "",
        vagitarian: toInt(fd.get("vegetarian") || "0"),
        message: (fd.get("message") || "").toString(),
        anyWord: (fd.get("message") || "").toString(),
        totalGuests: toInt(fd.get("adults") || "0") + toInt(fd.get("kids") || "0"),
        sourceTag,
        submittedAt: new Date().toISOString(),
        userAgent: navigator.userAgent,
        page: location.href
      };

      const err = validate(payload);
      if (err) {
        renderStatus(err, "err");
        return;
      }

      if (!endpoint) {
        renderStatus("尚未設定 googleScriptEndpoint，請先在 config.js 填入 Apps Script Web App URL。", "err");
        return;
      }

      submitBtn.disabled = true;
      renderStatus("送出中，請稍候...", "");

      try {
        const requestInit = {
          method: "POST",
          headers: {
            "Content-Type": "text/plain;charset=utf-8"
          },
          body: JSON.stringify(payload)
        };

        if (useNoCors) {
          requestInit.mode = "no-cors";
        }

        const response = await fetch(endpoint, requestInit);
        if (!useNoCors && !response.ok) {
          throw new Error("HTTP_" + response.status);
        }

        renderStatus("送出成功，謝謝你的回覆。", "ok");
        form.reset();
        updateProgress();
      } catch (error) {
        console.error(error);
        renderStatus("送出失敗，請檢查 Apps Script 是否已部署為 Web App。", "err");
      } finally {
        submitBtn.disabled = false;
      }
    });
  }

  window.addEventListener("scroll", toggleFloatingRsvp, { passive: true });

  setCountdown();
  setInterval(setCountdown, 30 * 1000);
  updateProgress();
  toggleFloatingRsvp();
})();
