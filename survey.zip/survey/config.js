window.APP_CONFIG = {
  // Google Apps Script Web App URL
  googleScriptEndpoint: "https://script.google.com/macros/s/AKfycbx5aZ1lEHUNn02JQKrDmB4BSpdrB9AcIezX7lNG53Syhs_obncTlptVGzD_bN-gJ3mG/exec",

  // Apps Script 常用 no-cors，避免跨網域讀取回應被擋
  useNoCors: true,

  sourceTag: "github-pages"
};
